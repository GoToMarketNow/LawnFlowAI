# LawnFlow.ai Seed Pack (Billing + Ops Demo)

Designed to showcase **Billing screens** + full app demos.

## Billing coverage
Invoices include at least one example of each status:
- DRAFT
- PENDING_APPROVAL
- SENT
- PAID
- PARTIAL
- OVERDUE
- VOID
- DISPUTED
- FAILED_SYNC

Payments include:
- SUCCEEDED
- PARTIAL (deposit)

Billing issues include:
- VARIANCE
- OVERDUE
- DISPUTE
- SYNC_ERROR

## Hierarchy
Leads/Customers → Quotes → Jobs → Invoices → Payments/Issues → Customer Comms

## Schedule constraint
All jobs occur between **08:00 and 20:00 ET**.

Time reference:
- 2026-01-05 (America/New_York)
