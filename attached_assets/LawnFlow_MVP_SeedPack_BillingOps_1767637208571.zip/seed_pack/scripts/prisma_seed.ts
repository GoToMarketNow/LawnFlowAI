/**
 * LawnFlow MVP Seed Runner (Billing Ops Demo) - Template
 */
import fs from "node:fs";
import path from "node:path";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();
const root = path.join(process.cwd(), "seed_pack", "data");
const readJson = (rel: string) => JSON.parse(fs.readFileSync(path.join(root, rel), "utf-8"));

async function main() {
  const account = readJson("accounts/account.json");
  const users = readJson("users/users.json");
  const crews = readJson("crews/crews.json");
  const customers = readJson("customers/customers.json");
  const leads = readJson("leads/leads.json");
  const jobs = readJson("jobs/jobs.json");
  const quotes = readJson("quotes/quotes.json");
  const invoices = readJson("billing/invoices/invoices.json");
  const payments = readJson("billing/payments/payments.json");
  const issues = readJson("billing/issues/issues.json");
  const threads = readJson("comms/threads.json");
  const messages = readJson("comms/messages.json");

  console.log("Loaded seed JSON counts:", {
    users: users.length,
    crews: crews.length,
    customers: customers.length,
    leads: leads.length,
    jobs: jobs.length,
    quotes: quotes.length,
    invoices: invoices.length,
    payments: payments.length,
    issues: issues.length,
    threads: threads.length,
    messages: messages.length,
  });

  // TODO: Upsert in dependency order.
  // await prisma.account.upsert({ where:{ id: account.id }, update: account, create: account });
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(async () => { await prisma.$disconnect(); });
