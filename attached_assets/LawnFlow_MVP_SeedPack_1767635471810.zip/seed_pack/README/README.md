# LawnFlow.ai Seed Pack (MVP)

This seed dataset is designed for demo + simulation:
- Crews + crew members
- Customers + site preferences (mulch/firewood examples)
- Leads (multi-channel)
- Jobs scheduled ONLY between 08:00 and 20:00 Eastern Time
- Quotes + invoices + comms threads for Work Queue/Approvals/Comms tiles

**Time reference**
- Current date assumed: 2026-01-05
- Timezone: America/New_York

## Folder structure
- `seed_pack/data/*` JSON datasets
- `seed_pack/scripts/*` seed runner templates

## Quick use
- Copy `seed_pack/` into your repo root (or adapt the paths)
- Implement upserts in `seed_pack/scripts/prisma_seed.ts` to match your schema
