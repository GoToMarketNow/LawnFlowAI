/**
 * LawnFlow MVP Seed Runner (Template)
 * Adapt model names/fields to your Prisma schema.
 *
 * Suggested approach:
 * - Upsert Account
 * - Upsert Users
 * - Upsert Crews
 * - Upsert Customers/Leads
 * - Upsert Jobs/Quotes/Invoices
 * - Upsert Comms Threads/Messages
 */
import fs from "node:fs";
import path from "node:path";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();
const root = path.join(process.cwd(), "seed_pack", "data");

function readJson(rel: string) {
  return JSON.parse(fs.readFileSync(path.join(root, rel), "utf-8"));
}

async function main() {
  const account = readJson("accounts/account.json");
  const users = readJson("users/users.json");
  const crews = readJson("crews/crews.json");
  const customers = readJson("customers/customers.json");
  const leads = readJson("leads/leads.json");
  const jobs = readJson("jobs/jobs.json");
  const quotes = readJson("quotes/quotes.json");
  const invoices = readJson("invoices/invoices.json");
  const threads = readJson("comms/threads.json");
  const messages = readJson("comms/messages.json");

  console.log("Loaded seed JSON:", {
    account: account.id,
    users: users.length,
    crews: crews.length,
    customers: customers.length,
    leads: leads.length,
    jobs: jobs.length,
    quotes: quotes.length,
    invoices: invoices.length,
    threads: threads.length,
    messages: messages.length,
  });

  // TODO: Implement upserts matching your schema.
  // Example:
  // await prisma.account.upsert({ where:{ id: account.id }, update: account, create: account });

  console.log("Implement upserts in this script to match your Prisma schema.");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(async () => { await prisma.$disconnect(); });
